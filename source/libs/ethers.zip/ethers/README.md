Firefly
=======

A simple, low-cost Ethereum wallet.

**Features:**

- **Line-of-sight** - Transactions can only be signed if the Firefly can physically be seen
- **Cheap** - $12 worth of components
- **Secure** - 
- **Simple to Use** - 

Additional Documentation
------------------------

[How to Build](docs.ethers.io w/ embedded YouTube video)

License
-------

BSD + MIT License. See individual files.
